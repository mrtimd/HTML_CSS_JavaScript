document.getElementById('generate').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      function: generateTOC
    });
  });
});

function generateTOC() {
  // Find all links on the page
  const links = document.querySelectorAll('a');
  const tocContainer = document.createElement('div');
  tocContainer.style.position = 'fixed';
  tocContainer.style.top = '10px';
  tocContainer.style.right = '10px';
  tocContainer.style.width = '200px';
  tocContainer.style.maxHeight = '80vh';
  tocContainer.style.overflowY = 'auto';
  tocContainer.style.backgroundColor = 'white';
  tocContainer.style.border = '1px solid #ccc';
  tocContainer.style.padding = '10px';
  tocContainer.style.zIndex = '9999';

  const ul = document.createElement('ul');

  links.forEach((link, index) => {
    const li = document.createElement('li');
    const a = document.createElement('a');
    a.href = link.href;
    a.textContent = link.textContent || `Link ${index + 1}`;
    a.style.display = 'block';
    a.style.marginBottom = '5px';

    a.addEventListener('click', (e) => {
      e.preventDefault();
      window.scrollTo({ top: link.offsetTop, behavior: 'smooth' });
    });

    li.appendChild(a);
    ul.appendChild(li);
  });

  // Remove previous TOC if exists
  const existingTOC = document.getElementById('toc-container');
  if (existingTOC) {
    existingTOC.remove();
  }

  tocContainer.id = 'toc-container';
  tocContainer.appendChild(ul);
  document.body.appendChild(tocContainer);
}