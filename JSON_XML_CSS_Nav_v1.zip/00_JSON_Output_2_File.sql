--T_SKWEL_&_AppDev_2018_BY_TDBRAND - CTRL + SHIFT + R will remove the red squiggly underline and clear the cache of the Intellisense.- 08/30/2017

--00_JSON_Output_2_File.sql 07/05/18 - Convert SQL Server data to JSON or export JSON Format SQL Server data or the results of SQL queries as JSON by adding the FOR JSON clause to a SELECT statement.

--2018: https://docs.microsoft.com/en-us/sql/relational-databases/json/format-query-results-as-json-with-for-json-sql-server?view=sql-server-2017

--Use with XML and JSON outputs to file system - consume from web page with xmlHttpRequest() - SQL 2012 FOR XML - 2016 FOR JSON support
 
 --Step 1. Create XML or JSON from relational or otherwise - OUTPUT to file for XMLHttpRequest() consumption.
 
 --Step 2. Add "consumption" to application - how does the app load data to a web resource?  XMLHttpRequest - Server Side File Handler - PHP, ASP, T-SQL - Other?

 --The FOR JSON PATH option uses dot-separated aliases in the SELECT clause to nest objects in the query results.
 
 --Connect to appropriate dbase with SELECT - example for syntax purposes with FOR JSON PATH output.

 USE T_SQL_2018

  SELECT empid, firstname AS "info.name", lastName AS "info.surname", city, birthdate AS dob
 FROM HR.Employees
 FOR JSON PATH

 --Send to text file

 --Overwrite destination file - no date stamp..

DECLARE @FileNameExpJSON varchar(50),
        @bcpCommandExpJSON varchar(2000)

--Use correct file path.

SET @FileNameExpJSON = 'C:\T_Labs\Data_Exports\Navigation_JSON.txt'

--Use correct SELECT statement..

SET @bcpCommandExpJSON = 'bcp "SELECT empid, firstname FROM T_SQL_2018.HR.Employees FOR JSON PATH" queryout "'

SET @bcpCommandExpJSON = @bcpCommandExpJSON + @FileNameExpJSON + '" -c -T'

EXEC master..xp_cmdshell @bcpCommandExpJSON