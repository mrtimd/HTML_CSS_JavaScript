--00_VIEW_UPDATE_TABLES.sql
/*-- 762 - p53: LISTING 1-2 Creating a view that meets the user requirements - 

-provide access to orders made in the last 12 months (to the day), 
-where there were more than one line items in that order. 
They only need to see the Line items, Customer, SalesPerson, Date ofOrder, 
and when it was likely to be delivered by.
*/

USE WideWorldImporters

CREATE VIEW Sales.vOrders12MonthsMultipleItems
AS

--See the Line items, Customer, SalesPerson, Date ofOrder, 
SELECT OrderId, CustomerID, SalespersonPersonID, OrderDate, ExpectedDeliveryDate
FROM Sales.Orders --73595 rows in this SELECT
--order by OrderDate desc
--Provide access to orders made in the last 12 months (to the day) - this didnt work with -12 as the dates in the db were older - 2016
WHERE OrderDate >= DATEADD(Month,-48,SYSDATETIME())
AND (
--Where there were more than one line items in that order.
SELECT COUNT(*) --231412 rows
FROM Sales.OrderLines 
WHERE OrderLines.OrderID = Orders.OrderID) > 1;

--Now the user can simply query the data using this view, just like a table:

SELECT TOP 5 *
FROM Sales.vOrders12MonthsMultipleItems
ORDER BY ExpectedDeliveryDate desc;

-- Consider this subsection of the Application.People table in WideWorldImporters database.

--A common request from a user that needs to look at this data using Transact-SQL could be: “I would like to see the data in the People table in a more user friendly manner.

SELECT PersonId, IsPermittedToLogon, IsEmployee, IsSalesPerson
FROM Application.People;

--LISTING 1-3 Creating the view reformat some columns in the Application.People table
DROP VIEW Application.vPeopleEmployeeStatus

CREATE VIEW Application.vPeopleEmployeeStatus
AS
SELECT PersonId, FullName,
IsPermittedToLogon, IsEmployee, IsSalesPerson,
CASE WHEN IsPermittedToLogon = 1 THEN 'Can Logon'
ELSE 'Can''t Logon' END AS LogonRights,
CASE WHEN IsEmployee = 1 and IsSalesPerson = 1
THEN 'Sales Person'
WHEN IsEmployee = 1
THEN 'Regular'
ELSE 'Not Employee' END AS EmployeeType
FROM Application.People;

--Now, querying the data in the same manner (leaving off names), you see something more pleasant to work with:

SELECT PersonId, LogonRights, EmployeeType
FROM Application.vPeopleEmployeeStatus;


--Build a simple reporting interface that allows us to see sales proft or net income broken down by city, state, or territory customer category for the current week, up to the most current data”

--LISTING 1-4 Creating the view that is the basis of an Invoice Summary report
DROP VIEW Reports.vInvoiceSummaryBasis
DROP SCHEMA Reports;
GO


CREATE SCHEMA Reports;
GO
CREATE VIEW Reports.vInvoiceSummaryBasis
AS
SELECT Invoices.InvoiceId, CustomerCategories.CustomerCategoryName,
Cities.CityName, StateProvinces.StateProvinceName,
StateProvinces.SalesTerritory,
Invoices.InvoiceDate,

--the grain of the report is at the invoice, so total
--the amounts for invoice

SUM(InvoiceLines.LineProfit) as InvoiceProfit,
SUM(InvoiceLines.ExtendedPrice) as InvoiceExtendedPrice
FROM Sales.Invoices
JOIN Sales.InvoiceLines
ON Invoices.InvoiceID = InvoiceLines.InvoiceID
JOIN Sales.Customers
ON Customers.CustomerID = Invoices.CustomerID
JOIN Sales.CustomerCategories
ON Customers.CustomerCategoryID =
CustomerCategories.CustomerCategoryID
JOIN Application.Cities
ON Customers.DeliveryCityID = Cities.CityID
JOIN Application.StateProvinces
ON StateProvinces.StateProvinceID = Cities.StateProvinceID
GROUP BY Invoices.InvoiceId, CustomerCategories.CustomerCategoryName,
Cities.CityName, StateProvinces.StateProvinceName,
StateProvinces.SalesTerritory,
Invoices.InvoiceDate;

--Now you can create a report of the top 5 Sales by SalesTerritory pretty simply:

SELECT TOP 5 SalesTerritory, SUM(InvoiceProfit) AS InvoiceProfitTotal
FROM Reports.vInvoiceSummaryBasis
WHERE InvoiceDate > '2016-05-01'
GROUP BY SalesTerritory
ORDER BY InvoiceProfitTotal DESC;
Go
--Updateable Views....p57

--LISTING 1-5 Creating the table and some data that is the basis of the updatable view example
CREATE SCHEMA Examples
Go

CREATE TABLE Examples.Gadget
(
GadgetId int NOT NULL CONSTRAINT PKGadget PRIMARY KEY,
GadgetNumber char(8) NOT NULL CONSTRAINT AKGadget UNIQUE,
GadgetType varchar(10) NOT NULL
);
INSERT INTO Examples.Gadget(GadgetId, GadgetNumber, GadgetType)
VALUES (1,'00000001','Electronic'),
(2,'00000002','Manual'),
(3,'00000003','Manual');

SELECT * FROM Examples.Gadget
Go
--LISTING 1-6 Creating the view that is the basis of an Invoice Summary report - use the WHERE to limit update column scope

DROP VIEW Examples.vElectronicGadget
Go

CREATE VIEW Examples.vElectronicGadget
AS
SELECT GadgetId, GadgetNumber, GadgetType,
UPPER(GadgetType) AS UpperGadgetType
FROM Examples.Gadget
WHERE GadgetType = 'Electronic';
Go
--the user sees:

SELECT vElectronicGadget.GadgetNumber AS FromView, Gadget.GadgetNumber AS FromTable,
Gadget.GadgetType, vElectronicGadget.UpperGadgetType
FROM Examples.vElectronicGadget
FULL OUTER JOIN Examples.Gadget
ON vElectronicGadget.GadgetId = Gadget.GadgetId;

--Now we run three statements to create some new rows, delete two rows, and update two rows in the table. 

INSERT INTO Examples.vElectronicGadget(GadgetId, GadgetNumber,
GadgetType, UpperGadgetType)
VALUES (4,'00000004', 'Electronic','XXXXXXXXXX'), --row we can see in view
(5,'00000005','Manual','YYYYYYYYYY'); --row we cannot see in view

/*This fails, as you would expect:
Msg 4406, Level 16, State 1, Line 433
Update or insert of view or function 'Examples.ElectronicGadget' failed because it contains UpperGadgetType - a derived or constant field*/

--try again, not referencing the calculated column: UpperGadgetType

INSERT INTO Examples.vElectronicGadget(GadgetId, GadgetNumber, GadgetType)
VALUES (4,'00000004','Electronic'),
(5,'00000005','Manual');
Go
--This succeeds, so now use the query with the FULL OUTER JOIN from before, but limit it to the rows you created.

SELECT vElectronicGadget.GadgetNumber as FromView, Gadget.GadgetNumber as FromTable,
Gadget.GadgetType, vElectronicGadget.UpperGadgetType
FROM Examples.vElectronicGadget
FULL OUTER JOIN Examples.Gadget
ON vElectronicGadget.GadgetId = Gadget.GadgetId

WHERE Gadget.GadgetId IN (4, 5);
Go
--Next, update two rows:

--Update the row we could see to values that could not be seen

UPDATE Examples.vElectronicGadget
SET GadgetType = 'Manual'
WHERE GadgetNumber = '00000007';

--Update the row we could see to values that could actually see

UPDATE Examples.vElectronicGadget
SET GadgetType = 'Electronic'
WHERE GadgetNumber = '00000008';

--When looking at the data (using the same query as before,) see that the row you could see has change to be not visible from the view, but the row we could not see was not updated:

--Since you cannot see the row in the results of a query of the view, you cannot update the row either

--LISTING 1-7 Altering the view to use the WITH CHECK OPTION
ALTER VIEW Examples.vElectronicGadget
AS
SELECT GadgetId, GadgetNumber, GadgetType,
UPPER(GadgetType) AS UpperGadgetType
FROM Examples.Gadget
WHERE GadgetType = 'Electronic'
WITH CHECK OPTION;

--Now, when you attempt to create a new row that would not be visible, you get an error. As an example, try the following:

INSERT INTO Examples.vElectronicGadget(GadgetId, GadgetNumber, GadgetType)
VALUES (6,'00000006','Manual');

--LISTING 1-8 Adding a table to go with the Examples.Gadget table to show a view with more than one table

CREATE TABLE Examples.GadgetType
(
GadgetType varchar(10) NOT NULL CONSTRAINT PKGadgetType PRIMARY KEY,
Description varchar(200) NOT NULL
)
INSERT INTO Examples.GadgetType(GadgetType, Description)
VALUES ('Manual','No batteries'),
('Electronic','Lots of bats');
ALTER TABLE Examples.Gadget
ADD CONSTRAINT FKGadget$ref$Examples_GadgetType
FOREIGN KEY (GadgetType) REFERENCES Examples.GadgetType (GadgetType);

--LISTING 1-9 View that references multiple tables
CREATE VIEW Examples.vGadgetExtension
AS
SELECT Gadget.GadgetId, Gadget.GadgetNumber,
Gadget.GadgetType, GadgetType.GadgetType As DomainGadgetType,
GadgetType.Description as GadgetTypeDescription
FROM Examples.Gadget
JOIN Examples.GadgetType
ON Gadget.GadgetType = GadgetType.GadgetType;

--Now try to insert a new gadget and gadget type simultaneously:

INSERT INTO Examples.vGadgetExtension(DomainGadgetType, GadgetTypeDescription)
VALUES('Acoustic','Sound');
INSERT INTO Examples.vGadgetExtension(GadgetId, GadgetNumber, GadgetType)
VALUES(7,'00000007','Acoustic');

--See that it works and, looking at the data, see that both rows have been created. Now, to see the UPDATE work, we update the description of one of the types. There are two rows where the GadgetType = ‘Electronic’.

SELECT *
FROM Examples.Gadget
JOIN Examples.GadgetType
ON Gadget.GadgetType = GadgetType.GadgetType
WHERE Gadget.GadgetType = 'Electronic';