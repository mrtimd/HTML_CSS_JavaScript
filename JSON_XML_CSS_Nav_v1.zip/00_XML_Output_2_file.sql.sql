-- T_SKWEL_STYLE_2018_BY_TDBRAND - CTRL + SHIFT + R will remove the red squiggly underline and clear the cache of the Intellisense. 

--00_XML_Output_2_file.sql 07/05/18 - Exporting Data from a Query to a Data File in XML format

--Use with XML and JSON outputs to file system - consume from web page with xmlHttpRequest() - SQL 2012 FOR XML - 2016 FOR JSON support

--The xp_cmdshell option required to execute BCP.exe from the query window. 
--Run the sp_configure system stored procedure as shown in the following code example:  

USE WideWorldImporters

-- To allow advanced options to be changed. 
EXEC sp_configure 'show advanced options', 1;  
GO  
-- To update the currently configured value for advanced options.  
RECONFIGURE;  
GO  
-- To enable the feature.  0 & reconfigure - will disable....
EXEC sp_configure 'xp_cmdshell', 1;  
GO  
-- To update the currently configured value for this feature.  
RECONFIGURE;  
GO  

--Is xp_cmdshell enabled?

SELECT CONVERT(INT, ISNULL(value, value_in_use)) AS config_value
FROM  sys.configurations
WHERE  name = 'xp_cmdshell' ;

--Begin Example....
 
USE WideWorldImporters

--Overwrite destination file - no date stamp..

DECLARE @FileNameExpXML varchar(50),
        @bcpCommandExpXML varchar(2000)

--Use correct path and filename
SET @FileNameExpXML = 'C:\T_Labs\Data_Exports\xml_Format.txt'

--Change T-SQL to correct SELECT for the job
-- FOR XML AUTO, - outputs query in XML format
--ELEMENTS" queryout - bulk copy program cmd..

SET @bcpCommandExpXML = 'bcp "SELECT OrderId, CustomerID, SalespersonPersonID, OrderDate, ExpectedDeliveryDate
FROM Sales.Orders FOR XML AUTO, ELEMENTS" queryout "'

SET @bcpCommandExpXML = @bcpCommandExpXML + @FileNameExpXML + '" -c -T'

EXEC master..xp_cmdshell @bcpCommandExpXML
